; FoxOS - 64-bit kernel with a VGA text-mode desktop and shell
; NASM flat binary, loaded at physical address 0x8000

bits 16
org 0x8000

entry:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00

    ; VGA text mode keeps the display's built-in character font available.
    mov ax, 0x0003
    int 0x10

    ; Enable A20.
    in al, 0x92
    or al, 2
    and al, 0xFE
    out 0x92, al

    ; Verify CPUID availability.
    pushfd
    pop eax
    mov ecx, eax
    xor eax, 1 << 21
    push eax
    popfd
    pushfd
    pop eax
    push ecx
    popfd
    xor eax, ecx
    test eax, 1 << 21
    jz cpu_error

    ; Check extended CPUID support and long mode.
    mov eax, 0x80000000
    cpuid
    cmp eax, 0x80000001
    jb cpu_error

    mov eax, 0x80000001
    cpuid
    test edx, 1 << 29
    jz cpu_error

    ; Clear page tables.
    mov edi, 0x1000
    xor eax, eax
    mov ecx, 3072
    rep stosd

    ; PML4[0] -> PDPT, PDPT[0] -> page directory.
    mov dword [0x1000], 0x2007
    mov dword [0x2000], 0x3007

    ; Identity-map the first 1 GiB using 2 MiB pages.
    mov edi, 0x3000
    mov eax, 0x83
    mov ecx, 512
.map_pages:
    mov [edi], eax
    mov dword [edi + 4], 0
    add eax, 0x200000
    add edi, 8
    loop .map_pages
    ; Give user mode access only to the 4-6 MiB region for its code and stack.
    mov dword [0x3010], 0x400087

    lgdt [gdt_pointer]

    mov eax, cr4
    or eax, 1 << 5
    mov cr4, eax

    mov eax, 0x1000
    mov cr3, eax

    mov ecx, 0xC0000080
    rdmsr
    or eax, 1 << 8
    wrmsr

    mov eax, cr0
    or eax, 0x80000001
    mov cr0, eax
    jmp 0x08:long_mode

cpu_error:
    cli
.error_halt:
    hlt
    jmp .error_halt

align 8
gdt_start:
    dq 0
    dq 0x00AF9A000000FFFF
    dq 0x00CF92000000FFFF
    dq 0x00AFFA000000FFFF
    dq 0x00CFF2000000FFFF
    dw 103
    dw 0
    db 0
    db 0x89
    db 0
    db 0
    dd 0
    dd 0
tss_descriptor equ gdt_start + 5 * 8
gdt_end:

gdt_pointer:
    dw gdt_end - gdt_start - 1
    dd gdt_start

bits 64
default abs

%macro WRITE_TEXT 3
    mov edi, %1
    mov byte [text_attr], %2
    mov rsi, %3
    call write_text
%endmacro

long_mode:
    cld
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov fs, ax
    mov gs, ax

    mov rsp, 0x90000
    xor rbp, rbp
    mov rax, tss
    mov word [tss_descriptor + 2], ax
    shr rax, 16
    mov byte [tss_descriptor + 4], al
    shr rax, 8
    mov byte [tss_descriptor + 7], al
    shr rax, 8
    mov dword [tss_descriptor + 8], eax
    mov qword [tss + 4], 0x90000
    mov word [tss + 102], 104
    mov ax, 0x28
    ltr ax
    call setup_syscall_gate

    mov rsi, user_program_start
    mov rdi, 0x400000
    mov rcx, user_program_end - user_program_start
    rep movsb

    mov byte [screen_mode], 0
    call draw_desktop
    call enter_user_mode

user_program_finished:
    mov rsp, 0x90000
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov ss, ax

keyboard_loop:
    in al, 0x64
    test al, 1
    jz keyboard_loop
    in al, 0x60

    ; Ignore key releases and extended scancodes.
    test al, 0x80
    jnz keyboard_loop
    cmp al, 0xE0
    je keyboard_loop

    cmp al, 0x3B
    je .show_terminal
    cmp al, 0x3C
    je .show_desktop
    cmp byte [screen_mode], 1
    jne keyboard_loop
    call terminal_key
    jmp keyboard_loop

.show_terminal:
    mov byte [screen_mode], 1
    call terminal_screen
    jmp keyboard_loop

.show_desktop:
    mov byte [screen_mode], 0
    call draw_desktop
    jmp keyboard_loop

setup_syscall_gate:
    mov rax, syscall_entry
    mov word [idt + 0x80 * 16], ax
    mov word [idt + 0x80 * 16 + 2], 0x08
    mov byte [idt + 0x80 * 16 + 4], 0
    mov byte [idt + 0x80 * 16 + 5], 0xEE
    shr rax, 16
    mov word [idt + 0x80 * 16 + 6], ax
    shr rax, 16
    mov dword [idt + 0x80 * 16 + 8], eax
    mov dword [idt + 0x80 * 16 + 12], 0
    lidt [idt_pointer]
    ret

enter_user_mode:
    mov ax, 0x23
    mov ds, ax
    mov es, ax
    push qword 0x23
    push qword 0x5FFFE0
    pushfq
    push qword 0x1B
    push qword 0x400000
    iretq

syscall_entry:
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    cmp rax, 1
    je .write
    cmp rax, 60
    je .exit
    mov rax, -38
    jmp .return

.write:
    mov rax, rsi
    cmp rax, 0x400000
    jb .bad_pointer
    add rax, rdx
    jc .bad_pointer
    cmp rax, 0x600000
    ja .bad_pointer
    mov r12, rsi
    mov r13, rdx
    mov r14, [user_cursor]
    mov rdi, 0xB8000
.write_next:
    test r13, r13
    jz .write_done
    cmp r14, 2000
    jae .write_done
    mov al, [r12]
    inc r12
    dec r13
    cmp al, 10
    je .newline
    mov ah, 0x0F
    mov rbx, r14
    shl rbx, 1
    mov [rdi + rbx], ax
    inc r14
    jmp .write_next
.newline:
    mov eax, r14d
    xor edx, edx
    mov ebx, 80
    div ebx
    inc eax
    imul eax, eax, 80
    mov r14, rax
    jmp .write_next
.write_done:
    mov [user_cursor], r14
    mov rax, [rsp + 16]
    jmp .return
.bad_pointer:
    mov rax, -14
    jmp .return

.exit:
    mov rsp, 0x90000
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov ss, ax
    jmp user_program_finished

.return:
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    iretq

draw_desktop:
    mov ax, 0x1F20
    mov edi, 0xB8000
    mov ecx, 2000
    rep stosw

    ; Top panel.
    mov ax, 0x7020
    mov edi, 0xB8000
    mov ecx, 80
    rep stosw
    WRITE_TEXT 0, 0x70, desktop_title

    ; A centered welcome window.
    WRITE_TEXT 0x01E8, 0x1F, window_border
    WRITE_TEXT 0x0238, 0x1F, window_title
    WRITE_TEXT 0x0288, 0x1F, window_border
    WRITE_TEXT 0x0330, 0x1F, desktop_welcome
    WRITE_TEXT 0x03D0, 0x1F, desktop_hint
    WRITE_TEXT 0x0468, 0x1F, desktop_keys
    WRITE_TEXT 0x04B8, 0x1F, window_border

    ; Bottom panel.
    mov ax, 0x7020
    mov edi, 0xB87A0
    mov ecx, 80
    rep stosw
    WRITE_TEXT 0x07A0, 0x70, taskbar_label
    ret

%include "shell/shell.asm"

write_text:
    mov [text_ptr], rsi
.next_char:
    mov rsi, [text_ptr]
    lodsb
    mov [text_ptr], rsi
    test al, al
    jz .done
    cmp edi, 2000
    jae .done
    mov ah, [text_attr]
    mov [0xB8000 + rdi * 2], ax
    inc edi
    jmp .next_char
.done:
    ret

desktop_title db " FOXOS DESKTOP", 0
window_border db "+--------------------------------------------------------------+", 0
window_title db "|                    WELCOME TO FOXOS                         |", 0
desktop_welcome db "FOXOS 64-BIT ASSEMBLY SYSTEM", 0
desktop_hint db "A tiny assembly desktop and command line.", 0
desktop_keys db "F1 opens the terminal. F2 returns to this desktop.", 0
taskbar_label db " FOXOS  |  F1 TERMINAL  |  F2 DESKTOP", 0

align 8
tss:
    times 104 db 0
idt_pointer:
    dw 4096 - 1
    dq idt
idt:
    times 256 * 16 db 0
user_cursor dq 1200
user_program_start:
    incbin "build/userland.bin"
user_program_end:

align 8
text_ptr dq 0
text_attr db 0
