# FoxOS

FoxOS is a small BIOS-booted x86-64 experiment written entirely in NASM
assembly, with an early C user-mode test program. It starts in a simple,
keyboard-operated desktop and includes an assembly command line.

## Build and run

Install NASM, GNU make, GCC, GNU binutils, and QEMU, then run:

```sh
make
make run
```

On Debian or Ubuntu, install QEMU on the host with
`sudo apt install qemu-system-x86`. If VS Code is running as a Flatpak, the
Makefile automatically tries `flatpak-spawn --host` when QEMU is not visible
inside the sandbox. You can also select a different emulator executable with
`make run QEMU=/path/to/qemu-system-x86_64`.

The disk image is `build/foxos.img`. The loader reads the kernel from the
second disk sector and currently reserves 32 sectors (16 KiB) for it.

## Controls

- **F1** opens the terminal.
- **F2** returns to the desktop.
- Terminal commands (lowercase): `help`, `about`, `clear`, `gui`, `reboot`,
  `halt`, and `shutdown`.

The desktop and terminal use VGA's standard 80x25 text mode. The desktop uses
colored text cells, and the terminal accepts keyboard input. Using the VGA
text mode avoids depending on a BIOS font copy after changing video modes.
Keyboard input is polled from the PS/2 controller.

## C user-mode foundation

The build compiles `userland/init.c` as a freestanding 64-bit program, links it
at `0x400000`, embeds it in the kernel image, and enters it at ring 3 during
startup. The initial `int 0x80` ABI supports `write` (1) to VGA text output
and `exit` (60). The program runs automatically at startup, prints a proof
message, exits, and then leaves the desktop and assembly shell available.
This is only an execution proof: the program is embedded, and FoxOS does not
yet have a general executable loader, filesystem, process model, or libc. GNU
Bash needs those foundations and a much broader POSIX system-call interface
before it can run.

## Adding a shell app

Shell input is in [shell/shell.asm](shell/shell.asm); individual command
handlers live in [apps/](apps/). Each app is a small NASM file. For example,
copy `apps/about.asm`, then give the new file a unique command name and a
handler that sets `output_ptr`:

```nasm
app_hello_name db "hello", 0

app_hello_run:
    mov rsi, hello_output
    mov [output_ptr], rsi
    ret

hello_output db "Hello from my app!", 0
```

Add `%include "apps/hello.asm"` and `APP_COMMAND hello` to
`apps/apps.asm`. Rebuild with `make`; the Makefile tracks app and shell source
files and rebuilds the kernel when they change. Apps are currently built into
the kernel image, so they are not yet separate files loaded at runtime.

This is a minimal starting point, not yet a pixel-graphics desktop: there is
no mouse, filesystem, multitasking, or interrupt-driven input.