static const char welcome[] = "C user program ran in ring 3; int 0x80 write succeeded.";

__attribute__((noreturn, section(".text.start")))
void _start(void)
{
    long syscall_number = 1;
    __asm__ volatile (
        "int $0x80"
        : "+a" (syscall_number)
        : "D" (1L), "S" (welcome), "d" ((long)(sizeof(welcome) - 1))
        : "rcx", "r11", "memory"
    );

    syscall_number = 60;
    __asm__ volatile (
        "int $0x80"
        :
        : "a" (syscall_number), "D" (0L)
        : "rcx", "r11", "memory"
    );

    for (;;) {
        __asm__ volatile ("pause");
    }
}
